# IO.Swagger.Api.UserManagementApi

All URIs are relative to *https://module-3-homework.swagger.io/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**DeleteUser**](UserManagementApi.md#deleteuser) | **DELETE** /user_management/delete | Delete User
[**GetUser**](UserManagementApi.md#getuser) | **GET** /user_management | Get Users
[**PutUser**](UserManagementApi.md#putuser) | **PUT** /user_management/ | Edit User

<a name="deleteuser"></a>
# **DeleteUser**
> void DeleteUser (string user = null)

Delete User

Delete One User

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DeleteUserExample
    {
        public void main()
        {
            var apiInstance = new UserManagementApi();
            var user = user_example;  // string | A member of the school. (optional) 

            try
            {
                // Delete User
                apiInstance.DeleteUser(user);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling UserManagementApi.DeleteUser: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user** | **string**| A member of the school. | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="getuser"></a>
# **GetUser**
> void GetUser (string user = null)

Get Users

Browse All Users OR Retrieve One User

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetUserExample
    {
        public void main()
        {
            var apiInstance = new UserManagementApi();
            var user = user_example;  // string | A member of the school. (optional) 

            try
            {
                // Get Users
                apiInstance.GetUser(user);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling UserManagementApi.GetUser: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user** | **string**| A member of the school. | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="putuser"></a>
# **PutUser**
> void PutUser (string user = null)

Edit User

Edit One User

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PutUserExample
    {
        public void main()
        {
            var apiInstance = new UserManagementApi();
            var user = user_example;  // string | A member of the school. (optional) 

            try
            {
                // Edit User
                apiInstance.PutUser(user);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling UserManagementApi.PutUser: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user** | **string**| A member of the school. | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
