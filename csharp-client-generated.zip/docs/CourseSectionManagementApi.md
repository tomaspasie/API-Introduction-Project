# IO.Swagger.Api.CourseSectionManagementApi

All URIs are relative to *https://module-3-homework.swagger.io/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**DeleteSection**](CourseSectionManagementApi.md#deletesection) | **DELETE** /course_section_management/delete | Delete Section
[**GetSection**](CourseSectionManagementApi.md#getsection) | **GET** /course_section_management | Get Sections
[**PutSection**](CourseSectionManagementApi.md#putsection) | **PUT** /course_section_management/ | Edit Section

<a name="deletesection"></a>
# **DeleteSection**
> void DeleteSection (string section = null)

Delete Section

Delete One Section

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DeleteSectionExample
    {
        public void main()
        {
            var apiInstance = new CourseSectionManagementApi();
            var section = section_example;  // string | A section to enroll teachers and students in. (optional) 

            try
            {
                // Delete Section
                apiInstance.DeleteSection(section);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CourseSectionManagementApi.DeleteSection: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **section** | **string**| A section to enroll teachers and students in. | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="getsection"></a>
# **GetSection**
> void GetSection (string section = null)

Get Sections

Browse All Sections OR Retrieve One Section

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetSectionExample
    {
        public void main()
        {
            var apiInstance = new CourseSectionManagementApi();
            var section = section_example;  // string | A section to enroll teachers and students in. (optional) 

            try
            {
                // Get Sections
                apiInstance.GetSection(section);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CourseSectionManagementApi.GetSection: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **section** | **string**| A section to enroll teachers and students in. | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="putsection"></a>
# **PutSection**
> void PutSection (string section = null)

Edit Section

Edit One Section

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PutSectionExample
    {
        public void main()
        {
            var apiInstance = new CourseSectionManagementApi();
            var section = section_example;  // string | A section to enroll teachers and students in. (optional) 

            try
            {
                // Edit Section
                apiInstance.PutSection(section);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CourseSectionManagementApi.PutSection: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **section** | **string**| A section to enroll teachers and students in. | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
