# IO.Swagger.Api.CourseAssignmentManagementApi

All URIs are relative to *https://module-3-homework.swagger.io/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**DeleteAssignment**](CourseAssignmentManagementApi.md#deleteassignment) | **DELETE** /course_assignment_management/delete | Delete Assignment
[**GetAssignment**](CourseAssignmentManagementApi.md#getassignment) | **GET** /course_assignment_management | Get Assignments
[**PutAssignment**](CourseAssignmentManagementApi.md#putassignment) | **PUT** /course_assignment_management/ | Edit Assignment

<a name="deleteassignment"></a>
# **DeleteAssignment**
> void DeleteAssignment (string assignment = null)

Delete Assignment

Delete One Assignment

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DeleteAssignmentExample
    {
        public void main()
        {
            var apiInstance = new CourseAssignmentManagementApi();
            var assignment = assignment_example;  // string | An assignment to be added to courses. (optional) 

            try
            {
                // Delete Assignment
                apiInstance.DeleteAssignment(assignment);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CourseAssignmentManagementApi.DeleteAssignment: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **assignment** | **string**| An assignment to be added to courses. | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="getassignment"></a>
# **GetAssignment**
> void GetAssignment (string assignment = null)

Get Assignments

Browse All Assignments OR Retrieve One Assignment

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetAssignmentExample
    {
        public void main()
        {
            var apiInstance = new CourseAssignmentManagementApi();
            var assignment = assignment_example;  // string | An assignment to be added to courses. (optional) 

            try
            {
                // Get Assignments
                apiInstance.GetAssignment(assignment);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CourseAssignmentManagementApi.GetAssignment: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **assignment** | **string**| An assignment to be added to courses. | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="putassignment"></a>
# **PutAssignment**
> void PutAssignment (string assignment = null)

Edit Assignment

Edit One Assignment

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PutAssignmentExample
    {
        public void main()
        {
            var apiInstance = new CourseAssignmentManagementApi();
            var assignment = assignment_example;  // string | An assignment to be added to courses. (optional) 

            try
            {
                // Edit Assignment
                apiInstance.PutAssignment(assignment);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CourseAssignmentManagementApi.PutAssignment: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **assignment** | **string**| An assignment to be added to courses. | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
