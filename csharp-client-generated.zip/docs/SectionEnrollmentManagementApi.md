# IO.Swagger.Api.SectionEnrollmentManagementApi

All URIs are relative to *https://module-3-homework.swagger.io/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**DeleteSectionEnrollment**](SectionEnrollmentManagementApi.md#deletesectionenrollment) | **DELETE** /section_enrollment_management/delete | Delete Section
[**GetSectionEnrollment**](SectionEnrollmentManagementApi.md#getsectionenrollment) | **GET** /section_enrollment_management | Get Sections
[**PutSectionEnrollment**](SectionEnrollmentManagementApi.md#putsectionenrollment) | **PUT** /section_enrollment_management/ | Edit Section

<a name="deletesectionenrollment"></a>
# **DeleteSectionEnrollment**
> void DeleteSectionEnrollment (string section = null)

Delete Section

Delete One Section

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DeleteSectionEnrollmentExample
    {
        public void main()
        {
            var apiInstance = new SectionEnrollmentManagementApi();
            var section = section_example;  // string | A section to assign teachers and students to. (optional) 

            try
            {
                // Delete Section
                apiInstance.DeleteSectionEnrollment(section);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SectionEnrollmentManagementApi.DeleteSectionEnrollment: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **section** | **string**| A section to assign teachers and students to. | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="getsectionenrollment"></a>
# **GetSectionEnrollment**
> void GetSectionEnrollment (string section = null)

Get Sections

Browse All Sections OR Retrieve One Section

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetSectionEnrollmentExample
    {
        public void main()
        {
            var apiInstance = new SectionEnrollmentManagementApi();
            var section = section_example;  // string | A section to assign teachers and students to. (optional) 

            try
            {
                // Get Sections
                apiInstance.GetSectionEnrollment(section);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SectionEnrollmentManagementApi.GetSectionEnrollment: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **section** | **string**| A section to assign teachers and students to. | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="putsectionenrollment"></a>
# **PutSectionEnrollment**
> void PutSectionEnrollment (string section = null)

Edit Section

Edit One Section

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PutSectionEnrollmentExample
    {
        public void main()
        {
            var apiInstance = new SectionEnrollmentManagementApi();
            var section = section_example;  // string | A section to assign teachers and students to. (optional) 

            try
            {
                // Edit Section
                apiInstance.PutSectionEnrollment(section);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SectionEnrollmentManagementApi.PutSectionEnrollment: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **section** | **string**| A section to assign teachers and students to. | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
