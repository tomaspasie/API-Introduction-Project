# IO.Swagger.Api.SectionAssignmentSubmissionManagementApi

All URIs are relative to *https://module-3-homework.swagger.io/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**DeleteAssignmentSubmission**](SectionAssignmentSubmissionManagementApi.md#deleteassignmentsubmission) | **DELETE** /section_assignment_submission_management/delete | Delete Assignment Submission
[**GetAssignmentSubmission**](SectionAssignmentSubmissionManagementApi.md#getassignmentsubmission) | **GET** /section_assignment_submission_management | Get Assignment Submissions
[**PutAssignmentSubmission**](SectionAssignmentSubmissionManagementApi.md#putassignmentsubmission) | **PUT** /section_assignment_submission_management/ | Edit Assignment Submission

<a name="deleteassignmentsubmission"></a>
# **DeleteAssignmentSubmission**
> void DeleteAssignmentSubmission (string assignment = null)

Delete Assignment Submission

Delete One Assignment Submission

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DeleteAssignmentSubmissionExample
    {
        public void main()
        {
            var apiInstance = new SectionAssignmentSubmissionManagementApi();
            var assignment = assignment_example;  // string | An assignment submission. (optional) 

            try
            {
                // Delete Assignment Submission
                apiInstance.DeleteAssignmentSubmission(assignment);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SectionAssignmentSubmissionManagementApi.DeleteAssignmentSubmission: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **assignment** | **string**| An assignment submission. | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="getassignmentsubmission"></a>
# **GetAssignmentSubmission**
> void GetAssignmentSubmission (string assignment = null)

Get Assignment Submissions

Browse All Assignments OR Retrieve One Assignment

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetAssignmentSubmissionExample
    {
        public void main()
        {
            var apiInstance = new SectionAssignmentSubmissionManagementApi();
            var assignment = assignment_example;  // string | An assignment submission. (optional) 

            try
            {
                // Get Assignment Submissions
                apiInstance.GetAssignmentSubmission(assignment);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SectionAssignmentSubmissionManagementApi.GetAssignmentSubmission: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **assignment** | **string**| An assignment submission. | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="putassignmentsubmission"></a>
# **PutAssignmentSubmission**
> void PutAssignmentSubmission (string assignment = null)

Edit Assignment Submission

Edit One Assignment

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PutAssignmentSubmissionExample
    {
        public void main()
        {
            var apiInstance = new SectionAssignmentSubmissionManagementApi();
            var assignment = assignment_example;  // string | An assignment submission. (optional) 

            try
            {
                // Edit Assignment Submission
                apiInstance.PutAssignmentSubmission(assignment);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SectionAssignmentSubmissionManagementApi.PutAssignmentSubmission: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **assignment** | **string**| An assignment submission. | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
