# IO.Swagger.Api.CourseManagementApi

All URIs are relative to *https://module-3-homework.swagger.io/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**DeleteCourse**](CourseManagementApi.md#deletecourse) | **DELETE** /course_management/delete | Delete Course
[**GetCourse**](CourseManagementApi.md#getcourse) | **GET** /course_management | Get Courses
[**PutCourse**](CourseManagementApi.md#putcourse) | **PUT** /course_management/ | Edit Course

<a name="deletecourse"></a>
# **DeleteCourse**
> void DeleteCourse (string course = null)

Delete Course

Delete One Course

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DeleteCourseExample
    {
        public void main()
        {
            var apiInstance = new CourseManagementApi();
            var course = course_example;  // string | A course a student takes. (optional) 

            try
            {
                // Delete Course
                apiInstance.DeleteCourse(course);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CourseManagementApi.DeleteCourse: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **course** | **string**| A course a student takes. | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="getcourse"></a>
# **GetCourse**
> void GetCourse (string course = null)

Get Courses

Browse All Courses OR Retrieve One Course

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetCourseExample
    {
        public void main()
        {
            var apiInstance = new CourseManagementApi();
            var course = course_example;  // string | A course a student takes. (optional) 

            try
            {
                // Get Courses
                apiInstance.GetCourse(course);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CourseManagementApi.GetCourse: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **course** | **string**| A course a student takes. | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="putcourse"></a>
# **PutCourse**
> void PutCourse (string course = null)

Edit Course

Edit One Course

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PutCourseExample
    {
        public void main()
        {
            var apiInstance = new CourseManagementApi();
            var course = course_example;  // string | A course a student takes. (optional) 

            try
            {
                // Edit Course
                apiInstance.PutCourse(course);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CourseManagementApi.PutCourse: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **course** | **string**| A course a student takes. | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
